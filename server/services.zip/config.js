// Hold application configs

module.exports = {

    secret: 'abcasdfkjaslkdfj',
    serverListeningPort: 3090,
    mongoDBAddress: 'mongodb://127.0.0.1:27017/CoffeeShop',
    socketIOAddress: '*http://localhost:8080',
    // role: {
    //     'ADMIN': 1,
    //     'BRANCH_ADMIN': 2,
    //     'BRANCH_USER': 3
    // }
};