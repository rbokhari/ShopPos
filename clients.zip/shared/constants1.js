module.exports = {

    USER_ROLE: {
        'ADMIN': 1,
        'BRANCH_ADMIN': 2,
        'BRANCH_USER': 3
    }
};